const socket = io();
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
canvas.width = 550;
canvas.height = window.innerHeight;

const angle = document.getElementById('angle');
const power = document.getElementById('power');
const fireBtn = document.getElementById('fire');
const joinBtn = document.getElementById('join');
const moveLeftBtn = document.getElementById('moveLeft');
const moveRightBtn = document.getElementById('moveRight');
const nameInput = document.getElementById('name');
const status = document.getElementById('status');

const aVal = document.getElementById('aVal');
const pVal = document.getElementById('pVal');

angle.oninput = () => { 
	aVal.textContent = angle.value; 
	const me = players.find(p => p.id === you);
	if (me) socket.emit('angleChange', { id: you, angle: +angle.value });
	draw(); 
};
power.oninput = () => { pVal.textContent = power.value; draw(); };

let you = null, players = [], order = [], currentTurn = null;
let tankX = { left: 10, right: 590 };
let movedPlayers = {};

function getGroundY(x) {
  const base = canvas.height * 0.7;
  const hillCenter = canvas.width / 2;
  const hillWidth = 500;
  const hillHeight = 1000;
  
  if (x < hillCenter - hillWidth / 2 || x > hillCenter + hillWidth / 2) {
    return base;
  }

  const t = (x - (hillCenter - hillWidth / 2)) / hillWidth; // normalize to [0,1]
  const y = (1 - t) * base + t * base + t * (1 - t) * (-hillHeight);
  return y;
}

joinBtn.onclick = () => socket.emit('join', nameInput.value || 'Player');
fireBtn.onclick = () => socket.emit('fire', { angle: +angle.value, power: +power.value });
moveLeftBtn.onclick = () => moveTank(-20);
moveRightBtn.onclick = () => moveTank(20);

function moveTank(dx) {
  const me = players.find(p => p.id === you);
  if (!me || you !== currentTurn || movedPlayers[you]) return;
  socket.emit('move', { side: me.side, dx });
}

socket.on('joined', ({ id }) => { you = id; });

socket.on('angleUpdate', ({ id, angle }) => {
  const p = players.find(p => p.id === id);
  if (p) p.angle = angle;
  draw();
});

socket.on('state', (s) => {
  players = s.players;
  order = s.order;
  currentTurn = s.currentTurn;
  tankX = s.tankX || tankX;
  movedPlayers = s.movedPlayers || {};
  fireBtn.disabled = you !== currentTurn;

  const me = players.find(p => p.id === you);
  if (me) {
    if (me.side === 'left') {
      moveLeftBtn.textContent = '← Хойш';
      moveRightBtn.textContent = '→ Урагш';
    } else if (me.side === 'right') {
      moveLeftBtn.textContent = '→ Урагш';
      moveRightBtn.textContent = '← Хойш';
    }
  }

  draw();
});

socket.on('shot', ({ id, angle, power }) => {
  const shooter = players.find(p => p.id === id);
  const fromLeft = shooter?.side === 'left';
  
  const tankX0 = fromLeft ? tankX.left : tankX.right;
  const tankY0 = getGroundY(tankX0);
  
  const gunOffsetX = fromLeft ? 28 : -28;
  const gunOffsetY = -8;
  
  const angleRad = fromLeft ? -angle * Math.PI / 180 :  angle * Math.PI / 180;
  
  
  let x = tankX0 + Math.cos(angleRad) * gunOffsetX - Math.sin(angleRad) * gunOffsetY;
  let y = tankY0 + Math.sin(angleRad) * gunOffsetX + Math.cos(angleRad) * gunOffsetY;

  
  let vx = fromLeft ? Math.cos(angleRad) * power : -Math.cos(angleRad) * power;
  let vy = fromLeft ? Math.sin(angleRad) * power : -Math.sin(angleRad) * power;  
  

  // function frame() {
    // x += vx * 0.1;
    // vy += 0.5;
    // y += vy * 0.1;
    // const groundY = getGroundY(x);
    // draw();
    // ctx.fillStyle = 'yellow';
    // ctx.beginPath();
    // ctx.arc(x, y, 3, 0, Math.PI * 2);
    // ctx.fill();

    // if (y > groundY) {
      // ctx.fillStyle = 'orange';
      // ctx.beginPath();
      // ctx.arc(x, groundY, 10, 0, Math.PI * 2);
      // ctx.fill();
      // const targetX = fromLeft ? tankX.right : tankX.left;
      // const hit = Math.abs(x - targetX) < 25;
      // socket.emit('hit', { hit });
      // return;
    // }
    // requestAnimationFrame(frame);
  // }
  // requestAnimationFrame(frame);
  
  let lastTime = performance.now();
  function frame(currentTime) {
    const dt = (currentTime - lastTime) / 1000; // delta time in seconds
    lastTime = currentTime;

    x += 10*vx * dt;
    vy += 50 * dt; // gravity acceleration
    y += 10*vy * dt;

    const groundY = getGroundY(x);

    draw(); // redraw everything
    ctx.fillStyle = 'yellow';
    ctx.beginPath();
    ctx.arc(x, y, 3, 0, Math.PI * 2);
    ctx.fill();

    if (y > groundY) {
      ctx.fillStyle = 'orange';
      ctx.beginPath();
      ctx.arc(x, groundY, 10, 0, Math.PI * 2);
      ctx.fill();

      const targetX = fromLeft ? tankX.right : tankX.left;
      const hit = Math.abs(x - targetX) < 25;
      socket.emit('hit', { hit });
      return;
    }

    requestAnimationFrame(frame);
  }

  requestAnimationFrame(frame);
});

function drawTank(x, y, side, angleDeg, isYou) {
  ctx.save();
  ctx.translate(x, y);
  if (side === 'right') ctx.scale(-1, 1);
  
  
  ctx.fillStyle = side === 'left' ? 'green' : 'red';
  ctx.fillRect(-15, -8, 30, 16);
  ctx.beginPath();
  ctx.arc(0, -8, 6, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.save();
  ctx.rotate(-angleDeg * Math.PI / 180);
  ctx.fillStyle = '#bbb';
  ctx.fillRect(8, -8, 20, 4);
  
  ctx.restore();
  ctx.restore();
}

function draw() {
  ctx.fillStyle = '#111';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  const base = canvas.height * 0.7;

  ctx.fillStyle = '#262';
  ctx.fillRect(0, base, canvas.width, canvas.height * 0.3);

  const hillCenter = canvas.width / 2;
  const hillWidth = 500;
  const hillHeight = 500;
  ctx.beginPath();
  ctx.moveTo(0, base);
  ctx.lineTo(hillCenter - hillWidth / 2, base);
  ctx.quadraticCurveTo(hillCenter, base - hillHeight, hillCenter + hillWidth / 2, base);
  ctx.lineTo(canvas.width, base);
  ctx.lineTo(canvas.width, canvas.height);
  ctx.lineTo(0, canvas.height);
  ctx.closePath();
  ctx.fillStyle = '#393';
  ctx.fill();

  const leftPlayer = players.find(p => p.side === 'left');
  const rightPlayer = players.find(p => p.side === 'right');
  
  const angLeft = leftPlayer?.id === you ? +angle.value : leftPlayer?.angle || 45;
  const angRight = rightPlayer?.id === you ? +angle.value : rightPlayer?.angle || 45;
 
  const leftY = getGroundY(tankX.left);
  const rightY = getGroundY(tankX.right);
  
  

  drawTank(tankX.left, leftY, 'left', angLeft, leftPlayer?.id === you);
  drawTank(tankX.right, rightY, 'right', angRight, rightPlayer?.id === you);

  const me = players.find(p => p.id === you);
  const turn = players.find(p => p.id === currentTurn);
  status.textContent =
    `Та: ${me?.name} (${me?.side})\n` +
    `Ээлж: ${turn?.name || '-'}\n\n` +
    players.map(p => `${p.name} (${p.side}): ${p.score}`).join('\n');
}


document.addEventListener('keydown', (e) => {
  if (!you) return; // skip if not a player

   
  let changed = false;

  switch (e.key) {
    case 'ArrowLeft':
      angle.value = Math.max(0, parseInt(angle.value) - 1);
      changed = true;
      break;
    case 'ArrowRight':
      angle.value = Math.min(90, parseInt(angle.value) + 1);
      changed = true;
      break;
    case 'ArrowUp':
      power.value = Math.min(100, parseInt(power.value) + 1);
      changed = true;
      break;
    case 'ArrowDown':
      power.value = Math.max(10, parseInt(power.value) - 1);
      changed = true;
      break;
  }

  if (changed) {
    // Trigger input events to update UI and tank rotation
    angle.dispatchEvent(new Event('input'));
    power.dispatchEvent(new Event('input'));
  }
});

angle.addEventListener('input', () => {
  // update angle display and draw gun
});

power.addEventListener('input', () => {
  // update power display if needed
});

document.addEventListener('keydown', (e) => {
  if (e.code === 'Space') {
    e.preventDefault(); // Space товчоор scroll хийхийг болиулах
    
    if (!fireBtn.disabled) {
      fireBtn.click(); // Галлах товчийг дарахтай адил үйлдэл
    }
  }
});



document.addEventListener('keydown', (e) => {
  if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Tab'].includes(e.key)) {
    if (document.activeElement && document.activeElement == document.body) {
      document.activeElement.blur();
      e.preventDefault();
    }
  }
});
