// ✅ server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const canvasWidth = 550;

app.use(express.static('public'));

let players = {};
let order = [];
let turn = 0;
let tankX = { left: 10, right: canvasWidth - 10 };
let movedPlayers = {};

function pushState() {
  io.emit('state', {
    players: Object.entries(players).map(([id, p]) => ({ id, ...p })),
    order,
    currentTurn: order[turn] || null,
    tankX,
    movedPlayers
  });
}

io.on('connection', (socket) => {
  socket.on('join', (name) => {
    const side = order.length === 0 ? 'left' : order.length === 1 ? 'right' : 'spectator';
    players[socket.id] = { name, side, score: 0, angle: 45, power: 50 };

    if (side === 'right') tankX.right = canvasWidth - 10;
    if (side === 'left') tankX.left = 10;

    if (side !== 'spectator') {
      order.push(socket.id);
      movedPlayers[socket.id] = false;
    }

    socket.emit('joined', { id: socket.id });
    pushState();
  });

  socket.on('fire', ({ angle, power }) => {
    const shooter = order[turn];
    if (socket.id !== shooter) return;

    players[socket.id].angle = angle;
    players[socket.id].power = power;

    io.emit('shot', { id: socket.id, angle, power });
    turn = (turn + 1) % order.length;
    for (const id of order) movedPlayers[id] = false;
    pushState();
  });

  socket.on('move', ({ side, dx }) => {
    const id = socket.id;
    if (id !== order[turn]) return;
    if (movedPlayers[id]) return;

    if (side === 'left') tankX.left += dx;
    else if (side === 'right') tankX.right += dx;

    movedPlayers[id] = true;
    pushState();
  });

  socket.on('hit', ({ hit }) => {
    const lastShooter = order[(turn + order.length - 1) % order.length];
    if (hit && players[lastShooter]) {
      players[lastShooter].score += 1;
      pushState();
    }
  });

  socket.on('disconnect', () => {
    delete players[socket.id];
    delete movedPlayers[socket.id];
    order = order.filter(id => id !== socket.id);
    turn = 0;
    pushState();
  });
  
  socket.on('angleChange', ({ id, angle }) => {
  if (players[id]) {
    players[id].angle = angle;
    io.emit('angleUpdate', { id, angle });
  }
});
  
});

server.listen(3000, () => console.log('Server started on http://localhost:3000'));
